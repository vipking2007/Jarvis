package com.jarvis.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.util.Log;

import androidx.core.app.NotificationCompat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class WakeWordService extends Service {

    private static final String TAG = "JARVIS_WAKE";
    private static final String CHANNEL_ID = "jarvis_wake_channel";
    private static final int NOTIF_ID = 1001;
    private static final long RESTART_DELAY_MS = 800;

    private final IBinder binder = new LocalBinder();
    private SpeechRecognizer speechRecognizer;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean isListening = false;
    private boolean appInForeground = false;
    private boolean shouldKeepRunning = true;

    private static final List<String> WAKE_WORDS = Arrays.asList(
            "hey jarvis", "jarvis", "ok jarvis", "hi jarvis",
            "hey davis", "hey travis", "hey marvel"  // common mishears
    );

    public class LocalBinder extends Binder {
        WakeWordService getService() { return WakeWordService.this; }
    }

    @Override
    public IBinder onBind(Intent intent) { return binder; }

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification("Listening for \"Hey JARVIS\"..."));
        startListening();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        shouldKeepRunning = true;
        if (!isListening) startListening();
        return START_STICKY; // Restart if killed
    }

    @Override
    public void onDestroy() {
        shouldKeepRunning = false;
        stopListening();
        super.onDestroy();
    }

    // ---- Listening ----
    public void startListening() {
        if (isListening || !shouldKeepRunning) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            Log.w(TAG, "Speech recognition not available");
            return;
        }

        handler.post(() -> {
            try {
                if (speechRecognizer != null) {
                    speechRecognizer.destroy();
                    speechRecognizer = null;
                }

                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
                speechRecognizer.setRecognitionListener(new WakeListener());

                Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US");
                intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
                intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
                intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 0);
                intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1500);
                intent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 1000);

                speechRecognizer.startListening(intent);
                isListening = true;
                Log.d(TAG, "Wake word listening started");
            } catch (Exception e) {
                Log.e(TAG, "Error starting recognition: " + e.getMessage());
                isListening = false;
                scheduleRestart();
            }
        });
    }

    public void stopListening() {
        handler.post(() -> {
            isListening = false;
            if (speechRecognizer != null) {
                try {
                    speechRecognizer.stopListening();
                    speechRecognizer.destroy();
                } catch (Exception e) { /* ignore */ }
                speechRecognizer = null;
            }
        });
    }

    public void setAppInForeground(boolean fg) {
        appInForeground = fg;
        // Update notification
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (nm != null) {
            nm.notify(NOTIF_ID, buildNotification(
                    fg ? "Active — say \"Hey JARVIS\"" : "Background — listening for \"Hey JARVIS\""
            ));
        }
    }

    private void scheduleRestart() {
        if (!shouldKeepRunning) return;
        handler.postDelayed(() -> {
            if (shouldKeepRunning && !isListening) startListening();
        }, RESTART_DELAY_MS);
    }

    private void onWakeWordDetected(String fullText) {
        Log.d(TAG, "Wake word detected in: " + fullText);

        // Extract command after wake word
        String command = fullText.toLowerCase().trim();
        for (String w : WAKE_WORDS) {
            command = command.replace(w, "").trim();
        }

        // Broadcast to MainActivity
        Intent intent = new Intent("com.jarvis.app.WAKE_WORD");
        intent.putExtra("command", command);
        sendBroadcast(intent);

        // Bring app to foreground
        Intent launch = new Intent(this, MainActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        startActivity(launch);

        // Pause then restart listening
        isListening = false;
        handler.postDelayed(this::startListening, 3500);
    }

    // ---- Recognition Listener ----
    private class WakeListener implements RecognitionListener {
        @Override
        public void onReadyForSpeech(Bundle params) {
            Log.d(TAG, "Ready for speech");
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
            ArrayList<String> data = partialResults.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION);
            if (data == null) return;
            for (String text : data) {
                String lower = text.toLowerCase().trim();
                for (String w : WAKE_WORDS) {
                    if (lower.contains(w)) {
                        speechRecognizer.stopListening();
                        isListening = false;
                        onWakeWordDetected(lower);
                        return;
                    }
                }
            }
        }

        @Override
        public void onResults(Bundle results) {
            isListening = false;
            ArrayList<String> data = results.getStringArrayList(
                    SpeechRecognizer.RESULTS_RECOGNITION);
            if (data != null) {
                for (String text : data) {
                    String lower = text.toLowerCase().trim();
                    for (String w : WAKE_WORDS) {
                        if (lower.contains(w)) {
                            onWakeWordDetected(lower);
                            return;
                        }
                    }
                }
            }
            // No wake word — restart
            scheduleRestart();
        }

        @Override
        public void onError(int error) {
            isListening = false;
            Log.d(TAG, "Recognition error: " + error);
            // Most errors are just silence/timeouts — restart
            switch (error) {
                case SpeechRecognizer.ERROR_NO_MATCH:
                case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
                case SpeechRecognizer.ERROR_CLIENT:
                    scheduleRestart();
                    break;
                case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
                    handler.postDelayed(WakeWordService.this::startListening, 2000);
                    break;
                default:
                    handler.postDelayed(WakeWordService.this::startListening, 3000);
            }
        }

        @Override public void onBeginningOfSpeech() {}
        @Override public void onRmsChanged(float rmsdB) {}
        @Override public void onBufferReceived(byte[] buffer) {}
        @Override public void onEndOfSpeech() {}
        @Override public void onEvent(int eventType, Bundle params) {}
    }

    // ---- Notification ----
    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "JARVIS Wake Word", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Listens for Hey JARVIS wake word");
            channel.setShowBadge(false);
            channel.enableVibration(false);
            channel.setSound(null, null);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private Notification buildNotification(String text) {
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, intent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("JARVIS")
                .setContentText(text)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentIntent(pi)
                .setOngoing(true)
                .setSilent(true)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .build();
    }
}
